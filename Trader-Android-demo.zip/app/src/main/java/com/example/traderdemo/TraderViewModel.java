package com.example.traderdemo;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

public class TraderViewModel extends AndroidViewModel {
    private static final String TAG = "TraderVM";
    private final MutableLiveData<Double> price = new MutableLiveData<>(1000.0);
    private final MutableLiveData<String> signal = new MutableLiveData<>("WAIT");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rand = new Random();
    private boolean running = false;

    private final Deque<Double> closes = new ArrayDeque<>();
    private static final int MAX_LOOKBACK = 200;

    public TraderViewModel(@NonNull Application application) {
        super(application);
    }

    public MutableLiveData<Double> getPrice() { return price; }
    public MutableLiveData<String> getSignal() { return signal; }
    public boolean isRunning() { return running; }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            double last = price.getValue() != null ? price.getValue() : 1000.0;
            double change = (rand.nextDouble() - 0.5) * 4.0;
            double next = last + change;
            if (closes.size()>=MAX_LOOKBACK) closes.removeFirst();
            closes.addLast(next);
            price.postValue(next);

            if (closes.size()>=20) {
                double maShort = ma(new ArrayDeque<>(closes), 5);
                double maLong = ma(new ArrayDeque<>(closes), 20);
                String prevSignal = signal.getValue();
                String newSignal = "WAIT";
                if (maShort > maLong) newSignal = "BUY";
                else if (maShort < maLong) newSignal = "SELL";
                if (!newSignal.equals(prevSignal)) {
                    signal.postValue(newSignal);
                    NotificationHelper.notify(getApplication().getApplicationContext(),
                            "Signal: " + newSignal,
                            String.format("Price: %.2f, MA5: %.2f, MA20: %.2f", next, maShort, maLong));
                }
            }

            if (running) handler.postDelayed(this, 1000);
        }
    };

    public void start() {
        if (running) return;
        running = true;
        handler.post(tick);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(tick);
    }

    private double ma(Deque<Double> data, int period) {
        double sum = 0;
        int count = 0;
        Double[] arr = data.toArray(new Double[0]);
        for (int i = Math.max(0, arr.length - period); i < arr.length; i++) {
            sum += arr[i];
            count++;
        }
        return count == 0 ? 0 : sum / count;
    }
}
