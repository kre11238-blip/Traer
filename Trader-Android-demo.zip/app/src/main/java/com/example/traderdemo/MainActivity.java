package com.example.traderdemo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class MainActivity extends AppCompatActivity {
    private TextView txtPrice, txtSignal;
    private Button btnStartStop;
    private TraderViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPrice = findViewById(R.id.txtPrice);
        txtSignal = findViewById(R.id.txtSignal);
        btnStartStop = findViewById(R.id.btnStartStop);

        viewModel = new ViewModelProvider(this).get(TraderViewModel.class);

        viewModel.getPrice().observe(this, price -> {
            txtPrice.setText(String.format("Price: %.2f", price));
        });

        viewModel.getSignal().observe(this, s -> {
            txtSignal.setText(s);
        });

        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewModel.isRunning()) {
                    viewModel.stop();
                    btnStartStop.setText("Start");
                } else {
                    viewModel.start();
                    btnStartStop.setText("Stop");
                }
            }
        });
    }
}
