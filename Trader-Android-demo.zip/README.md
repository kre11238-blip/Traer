Trader - Demo Android App (Java)

This is a demo trading app named "Trader" that simulates price ticks and generates BUY/SELL signals
using a MA crossover (MA5/MA20). It runs in demo mode by default.

How to use:
1. Download and unzip the project.
2. Open the project in Android Studio and let Gradle sync.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s) or run the included build script.

GitHub Actions:
- The project includes a workflow at .github/workflows/android-build.yml which builds the debug APK
  on every push/pull_request. After you upload this project to a GitHub repo, Actions will produce
  an artifact named app-debug.apk you can download from the Actions page.

Connecting to Exness later:
- Swap the price feed logic in TraderViewModel to pull from WebSocket (Exness) instead of the simulated feed.
