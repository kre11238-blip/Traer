Trader - Complete Demo App (Live-ready)

This package includes a finished Android Studio project for the Trader app configured for XPT/USD demo signals with pop-up notifications (sound + vibration).

What I included:
- Demo XPT/USD price feed (simulated) that triggers BUY/SELL signals via MA5/MA20 crossover.
- Pop-up notification with sound + vibration on each signal.
- Option to paste a public WebSocket URL to use live feeds (no credentials required).
- GitHub Actions workflow that installs Android command-line tools, SDK, and builds the debug APK on push.
- build_and_sign.sh helper to build locally if you have Android SDK/Gradle.

How to get the APK via GitHub Actions:
1. Create a GitHub repo and upload the contents of this folder.
2. After pushing, open the Actions tab; the 'Android Build' workflow will run and produce an artifact named app-debug.apk.
3. Download the artifact and install on your Android device.

If you want, I can attempt to build the APK here, but this environment may not have Android SDK installed. The GitHub Actions workflow is the most reliable route.
