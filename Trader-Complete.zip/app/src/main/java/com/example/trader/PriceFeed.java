package com.example.trader;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

import org.json.JSONObject;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class PriceFeed {

    public interface PriceListener {
        void onPrice(double price);
    }

    private static final String TAG = "PriceFeed";
    private final PriceListener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rand = new Random();
    private Timer demoTimer;
    private OkHttpClient client;
    private WebSocket ws;
    private String wsUrl;
    private boolean liveRunning = false;
    private Context ctx;

    public PriceFeed(Context ctx, PriceListener listener) {
        this.ctx = ctx;
        this.listener = listener;
    }

    public void startDemoXPT() {
        stop();
        demoTimer = new Timer();
        demoTimer.scheduleAtFixedRate(new TimerTask() {
            double price = 1656.70;
            @Override
            public void run() {
                price += (rand.nextDouble() - 0.48) * 3.5;
                listener.onPrice(price);
            }
        }, 0, 1500);
    }

    public void stop() {
        if (demoTimer != null) {
            demoTimer.cancel();
            demoTimer = null;
        }
        stopLive();
    }

    public void startLive(String url) {
        stop();
        wsUrl = url;
        liveRunning = true;
        client = new OkHttpClient.Builder()
                .pingInterval(20, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .build();
        connect();
    }

    private void connect() {
        if (!liveRunning || wsUrl == null) return;
        Request request = new Request.Builder().url(wsUrl).build();
        ws = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                Log.i(TAG, "WS open");
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                try {
                    JSONObject j = new JSONObject(text);
                    if (j.has("price")) {
                        double p = j.getDouble("price");
                        handler.post(() -> listener.onPrice(p));
                        return;
                    }
                    if (j.has("type") && j.optString("type").equals("ticker") && j.has("price")){
                        double p = Double.parseDouble(j.getString("price"));
                        handler.post(() -> listener.onPrice(p));
                        return;
                    }
                } catch (Exception e){}
                try {
                    String digits = text.replaceAll("[^0-9.\\-]"," ");
                    String[] parts = digits.trim().split("\\s+");
                    for (String part: parts){
                        if (part.length()>0){
                            double p = Double.parseDouble(part);
                            handler.post(() -> listener.onPrice(p));
                            break;
                        }
                    }
                } catch (Exception ex) {}
            }

            @Override
            public void onMessage(WebSocket webSocket, ByteString bytes) {}

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                webSocket.close(1000, null);
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                Log.e(TAG, "WS failure", t);
                if (liveRunning) {
                    handler.postDelayed(() -> connect(), 5000);
                }
            }
        });
    }

    private void stopLive() {
        liveRunning = false;
        try { if (ws != null) ws.cancel(); } catch (Exception e) {}
        try { if (client != null) client.dispatcher().executorService().shutdown(); } catch (Exception e) {}
        ws = null;
        client = null;
    }
}
