package com.example.trader;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class MainActivity extends AppCompatActivity {
    private TextView txtPrice, txtSignal;
    private Button btnStartStop;
    private EditText edtWsUrl;
    private Button btnSetLive;
    private TraderViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPrice = findViewById(R.id.txtPrice);
        txtSignal = findViewById(R.id.txtSignal);
        btnStartStop = findViewById(R.id.btnStartStop);
        edtWsUrl = findViewById(R.id.edtWsUrl);
        btnSetLive = findViewById(R.id.btnSetLive);

        viewModel = new ViewModelProvider(this).get(TraderViewModel.class);

        viewModel.getPrice().observe(this, price -> {
            txtPrice.setText(String.format("Price: %.2f", price));
        });

        viewModel.getSignal().observe(this, s -> {
            txtSignal.setText(s);
        });

        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewModel.isRunning()) {
                    viewModel.stop();
                    btnStartStop.setText("Start");
                } else {
                    viewModel.start();
                    btnStartStop.setText("Stop");
                }
            }
        });

        btnSetLive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = edtWsUrl.getText().toString().trim();
                if (!url.isEmpty()) {
                    viewModel.setLiveWebSocket(url);
                }
            }
        });

        edtWsUrl.setText("wss://ws-feed.pro.coinbase.com");
    }
}
