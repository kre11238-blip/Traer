package com.example.trader;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayDeque;
import java.util.Deque;

public class TraderViewModel extends AndroidViewModel {
    private final MutableLiveData<Double> price = new MutableLiveData<>(1656.70);
    private final MutableLiveData<String> signal = new MutableLiveData<>("WAIT");
    private boolean running = false;

    private final Deque<Double> closes = new ArrayDeque<>();
    private static final int MAX_LOOKBACK = 200;

    private PriceFeed feed;

    public TraderViewModel(@NonNull Application application) {
        super(application);
        feed = new PriceFeed(getApplication().getApplicationContext(), p -> onTick(p));
    }

    private void onTick(double next) {
        if (closes.size()>=MAX_LOOKBACK) closes.removeFirst();
        closes.addLast(next);
        price.postValue(next);

        if (closes.size()>=20) {
            double maShort = ma(new ArrayDeque<>(closes), 5);
            double maLong = ma(new ArrayDeque<>(closes), 20);
            String prevSignal = signal.getValue();
            String newSignal = "WAIT";
            if (maShort > maLong) newSignal = "BUY";
            else if (maShort < maLong) newSignal = "SELL";
            if (!newSignal.equals(prevSignal)) {
                signal.postValue(newSignal);
                NotificationHelper.notify(getApplication().getApplicationContext(),
                        "Signal: " + newSignal,
                        String.format("Price: %.2f", next),
                        newSignal.equals("BUY"));
            }
        }
    }

    public MutableLiveData<Double> getPrice() { return price; }
    public MutableLiveData<String> getSignal() { return signal; }
    public boolean isRunning() { return running; }

    public void start() {
        if (running) return;
        running = true;
        feed.startDemoXPT();
    }

    public void stop() {
        running = false;
        feed.stop();
    }

    public void setLiveWebSocket(String url) {
        feed.startLive(url);
    }

    private double ma(Deque<Double> data, int period) {
        double sum = 0;
        int count = 0;
        Double[] arr = data.toArray(new Double[0]);
        for (int i = Math.max(0, arr.length - period); i < arr.length; i++) {
            sum += arr[i];
            count++;
        }
        return count == 0 ? 0 : sum / count;
    }
}
