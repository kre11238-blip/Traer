#!/usr/bin/env bash
set -e
./gradlew assembleDebug
APK=app/build/outputs/apk/debug/app-debug.apk
if [ -f "$APK" ]; then
    cp "$APK" /mnt/data/Trader-Complete-app-debug.apk || true
    echo "APK copied to /mnt/data/Trader-Complete-app-debug.apk"
else
    echo "APK not found"
    exit 1
fi
